# Code Analysis Integration

A package to automate running pytest and transforming reports.

## Installation

```bash
pip install astronuts-python-reporter
```
## add this to your workflow file  (after installation is done)
```bash
astronuts-generate
```